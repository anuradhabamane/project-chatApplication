<?php
$conn = mysqli_connect("localhost","root","","echat") or die("Cant connect to DB");
?>